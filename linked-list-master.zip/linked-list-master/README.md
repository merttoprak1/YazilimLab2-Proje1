LINKED LIST

-----------------------------------------------------------------------------------------------------------------------------------------------------------------

A console application that reads words from txt file and inserts to a linked list sequentially according to the number of occurrences of those words in the txt file.
Written in C.
